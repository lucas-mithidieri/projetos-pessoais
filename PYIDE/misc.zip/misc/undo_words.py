import tkinter as tk
from tkinter import scrolledtext

class EditorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Editor Undo/Redo")

        self.text_widget = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=40, height=10)
        self.text_widget.pack(expand=True, fill='both')

        # Lista para armazenar os estados passados
        self.undo_stack = []
        # Lista para armazenar os estados futuros (para redo)
        self.redo_stack = []

        # Contador para manter a quantidade de itens no undo_stack
        self.undo_counter = 0

        # Configurar a função para rastrear mudanças no texto
        self.text_widget.bind("<Key>", self.track_changes)

    def track_changes(self, event):
        # Adicionar o estado atual à pilha de undo, excluindo o último caractere se for uma nova linha
        current_state = self.text_widget.get("1.0", tk.END)
        if current_state.endswith('\n'):
            current_state = current_state[:-1]
        self.undo_stack.append(current_state)
        
        # Incrementar o contador
        self.undo_counter += 1
        
        # Limpar a pilha de redo, já que uma nova alteração foi feita
        self.redo_stack = []

    # def undo_word(self):
    #     while self.undo_stack:
    #         # Obter o estado anterior
    #         last_state = self.undo_stack.pop()
    #         # Verificar se o último caractere do estado anterior é um espaço ou quebra de linha
    #         if last_state and last_state[-1]==' ': # last_state[-1].isspace():
    #             # Se for um caractere de espaço ou quebra de linha, interromper o loop
    #             break

    #         # Se o estado anterior não for vazio, decrementar o contador
    #         if last_state:
    #             self.undo_counter -= 1
            
    #     # Adicionar o estado atual à pilha de redo
    #     self.redo_stack.append(self.text_widget.get("1.0", tk.END)[:-1])
    #     # Atualizar o texto com o estado anterior, excluindo a última linha vazia
    #     self.text_widget.delete("1.0", tk.END)
    #     self.text_widget.insert(tk.END, last_state.strip())

    # def undo_word(self):
    #     # novo 1
    #     while self.undo_counter > 0:
    #         # Obter o estado anterior
    #         last_state = self.undo_stack.pop()
    #         # Decrementar o contador
    #         self.undo_counter -= 1

    #         # Verificar se o último caractere do estado anterior é um espaço ou quebra de linha
    #         if last_state and last_state[-1].isspace():
    #             # Se for um caractere de espaço ou quebra de linha, interromper o loop
    #             break
                
    #     # Adicionar o estado atual à pilha de redo
    #     self.redo_stack.append(self.text_widget.get("1.0", tk.END)[:-1])
    #     # Atualizar o texto com o estado anterior, excluindo a última linha vazia
    #     self.text_widget.delete("1.0", tk.END)
    #     self.text_widget.insert(tk.END, last_state.strip())

    def undo_word(self):
        last_state = ""
        while self.undo_counter > 0:
            # Obter o estado anterior
            last_state = self.undo_stack.pop()
            # Decrementar o contador
            self.undo_counter -= 1

            # Verificar se o último caractere do estado anterior é um espaço ou quebra de linha
            if last_state and last_state[-1].isspace():
                # Se for um caractere de espaço ou quebra de linha, interromper o loop
                break
                
        # Adicionar o estado atual à pilha de redo
        self.redo_stack.append(self.text_widget.get("1.0", tk.END)[:-1])
        # Atualizar o texto com o estado anterior, excluindo a última linha vazia
        self.text_widget.delete("1.0", tk.END)
        self.text_widget.insert(tk.END, last_state.strip())

    def redo(self):
        if self.redo_stack:
            # Obter o estado futuro
            next_state = self.redo_stack.pop()
            # Adicionar o estado atual à pilha de undo
            self.undo_stack.append(self.text_widget.get("1.0", tk.END))
            # Atualizar o texto com o estado futuro
            self.text_widget.delete("1.0", tk.END)
            self.text_widget.insert(tk.END, next_state)

if __name__ == "__main__":
    root = tk.Tk()
    app = EditorApp(root)

    # Adicionar botões de undo e redo
    undo_button = tk.Button(root, text="Undo Word", command=app.undo_word)
    undo_button.pack(side=tk.LEFT)
    redo_button = tk.Button(root, text="Redo", command=app.redo)
    redo_button.pack(side=tk.LEFT)

    root.mainloop()
