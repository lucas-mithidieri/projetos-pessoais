from tkinter import Frame,Text,Menu,Listbox,Toplevel,TclError, Scrollbar,LEFT, RIGHT,END,BOTH,Tk
from tkinter import simpledialog
import re
import types


def get_methods(obj, spacing=20, show_doc=False):
    """
    Obtém os métodos de um objeto e suas documentações.

    Args:
        obj (object): O objeto do qual os métodos serão obtidos.
        spacing (int): O espaçamento usado para formatar a saída.
        show_doc (bool): Se True, retorna um dicionário {'metodo':'documentacao'},
                        se False, retorna uma lista de nomes de métodos.

    Returns:
        list or dict: Uma lista de nomes de métodos se show_doc for False,
                      ou um dicionário {'metodo':'documentacao'} se show_doc for True.
    """
    result = []
    for method_name in dir(obj):
        try:
            method = getattr(obj, method_name)
            if callable(method):
                if show_doc:
                    doc = str(method.__doc__)[0:90] if method.__doc__ else ''
                    result.append({method_name: doc})
                else:
                    result.append(method_name)
        except Exception as e:
            result.append(f"getattr() failed for {method_name}: {str(e)}")

    return result

class MainWindow(Frame):
    def __init__(self, master=None, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.editor = Text(self,  padx=10, pady=10, tabs=(2,))
        self.editor.pack(expand=True, fill='both')

        # Create a menu bar
        menubar = Menu(root)
        root.config(menu=menubar)

        # Create a "File" menu
        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)

        # Add a command to the "File" menu
        file_menu.add_command(label="Exit", command=root.destroy)

        # Create an "Inspect" menu item outside the "File" menu
        menubar.add_command(label="Inspect", command=self.inspect_code)

        # Center the main window on the screen
        # Center the main window on the screen
        window_width = 800  # Set your desired width
        window_height = 600  # Set your desired height
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2

        root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        # hotkey binding
        root.bind('<Control-I>', self.inspect_code)
    
    def get_info_of_selection(self):
        try:
            index_start = self.editor.index("sel.first")
            index_end = self.editor.index("sel.last")
        except TclError:
            index_start = index_end = self.editor.index("insert")

        tex = self.editor.get(index_start,index_end)

        msg = f"start: {index_start}\nend: {index_end}"
        
        exec(tex)
        
    def inspect_code(self, event=None):
        # Get the selected text from the editor
        selected_code = self.editor.get("sel.first", "sel.last")
        
        # Check if there is any code to execute
        if selected_code:

            try:
                # Execute the code
                result = eval(selected_code)

                # Faz um dump dos metodos do Módulo 'biblioteca'
                if type(result) == types.ModuleType:
                    result = get_methods(result)

            except:
                try:
                    # Definindo um padrão para extrair a variável da string
                    pattern = r'^\s*([^=\s]+)\s*='
                    
                    # Procurando por uma correspondência no código selecionado
                    case = 0
                    match = re.search(pattern, selected_code)
                    case = 1 if match else 0

                    # import ou from
                    match, case = (re.search(r'\b(import|from)\s+\w+', selected_code),\
                        2) if case==0 else (match, case)

                    # metodo ou function call
                    match, case = (re.search(r'^\w+(?:\.\w+)?\s*\([^)]*\)\s*(?:\.\s*\w+\s*\()?', selected_code),\
                        3) if case==0 else (match, case)

                    if case == 1:
                        # Extraindo a variável da correspondência
                        result = match.group(1)

                        # Executando a atribuição global da variável no código
                        exec(f'global {result}; {selected_code}')

                        # pego a variavel recem criada
                        last_set_var = result

                        # Avaliando e armazenando o valor da última variável definida
                        result = globals()[last_set_var]

                    elif case == 2:
                        self.get_info_of_selection()

                        if match.group(1) == 'import':
                            pattern = r'import\s+([\w\s,]+)'
                            match = re.search(pattern, selected_code)
                            
                            libraries = [library.strip().split(' as ') for library in match.group(1).split(',')]

                            for lib in libraries:
                                # o proprio nome
                                nome = lib[0]
                                apelido = nome

                                if len(lib) > 1:
                                    # Com apelido
                                    apelido = lib[1]
                                
                                globals()[apelido] = __import__(nome)

                        result = True
                    elif case == 3:
                        # Verifica se é chamada de metodo ou funcao
                        c = f'result = {selected_code}'
                        exec(c)
                        print('é')
                    else:
                        # Lançando uma exceção se não encontrar a variável na string
                        raise ValueError("Problema com a string: não foi possível encontrar a variável")

                except Exception as e:
                    # Handle errors
                    self.add_to_listbox(f"Error: {e}")

            # Add the result to the Listbox
            self.add_to_listbox(result)
        else:
            # Handle case where no code is provided
            self.add_to_listbox("No code selected or entered.")

    def close_window(self, event): 
        if event.widget.widgetName == 'toplevel':
            event.widget.destroy()
        else:
            # Se não for Toplevel, feche o widget pai
            parent = event.widget.master
            parent.destroy()

    def add_to_listbox(self, result):
        # Create a new window for the inspection result
        
        self.inspect_window = Toplevel(self)

        inspect_result_window = self.inspect_window
        inspect_result_window.title("Inspect Result")
        inspect_result_window.focus()

        # Impede o redimensionamento horizontal e vertical
        inspect_result_window.resizable(width=False, height=False)

        # Hotkeys
        inspect_result_window.bind('<Escape>', self.close_window)

        # Set the width and height of the window
        inspect_result_window.geometry("300x50")

        # Make the "Inspect" window non-minimizable
        inspect_result_window.transient(root)

        # Add a Listbox to the inspection result window
        listbox = Listbox(inspect_result_window)
        # listbox.pack(expand=True, fill=BOTH)
        listbox.pack(side=LEFT, expand=True, fill=BOTH)

        # # Insert the result into the Listbox
        # listbox.insert(END, str(result))
        # Check if result is a list, array, or set
        if isinstance(result, (list, tuple, set)):
            # Add a vertical scrollbar to the Listbox
            scrollbar = Scrollbar(inspect_result_window, command=listbox.yview)
            scrollbar.pack(side=RIGHT, fill=BOTH)
            # Attaching Listbox to Scrollbar
            listbox.config(yscrollcommand=scrollbar.set)
            # Setting scrollbar command parameter
            scrollbar.config(command=listbox.yview)
            # Increase window size
            self.inspect_window.geometry(f"{300}x{230}")

            i = 0
            # If it is, iterate over the elements and insert them into the Listbox
            for item in result:
                listbox.insert(END, f'[{str(i)}] {str(item)}')
                i += 1
        else:
            # If it's not, insert the entire result into the Listbox
            listbox.insert(END, f'[{type(result).__name__}] {str(result)}')

        # Center the Listbox within the Toplevel window
        inspect_window = inspect_result_window
        root.update_idletasks()
        x = root.winfo_x() + (root.winfo_width() - inspect_window.winfo_reqwidth()) // 2
        y = root.winfo_y() + (root.winfo_height() - inspect_window.winfo_reqheight()) // 2

        # Set the position of the "Inspect" window to the center
        inspect_window.geometry(f"+{x}+{y}")

        print(result)

if __name__ == "__main__":
    root = Tk()
    main_window = MainWindow(root)
    main_window.pack(side='top', fill='both', expand=True)
    root.mainloop()
