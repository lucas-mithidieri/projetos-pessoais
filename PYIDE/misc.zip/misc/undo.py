import tkinter as tk
from tkinter import scrolledtext

class EditorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Editor Undo/Redo")

        self.text_widget = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=40, height=10)
        self.text_widget.pack(expand=True, fill='both')

        # Lista para armazenar os estados passados
        self.undo_stack = []
        # Lista para armazenar os estados futuros (para redo)
        self.redo_stack = []

        # Configurar a função para rastrear mudanças no texto
        self.text_widget.bind("<Key>", self.track_changes)

    def track_changes(self, event):
        # Adicionar o estado atual à pilha de undo
        self.undo_stack.append(self.text_widget.get("1.0", tk.END))
        # Limpar a pilha de redo, já que uma nova alteração foi feita
        self.redo_stack = []

    def undo(self):
        if self.undo_stack:
            # Obter o estado anterior
            last_state = self.undo_stack.pop()
            # Adicionar o estado atual à pilha de redo
            self.redo_stack.append(self.text_widget.get("1.0", tk.END))
            # Atualizar o texto com o estado anterior
            self.text_widget.delete("1.0", tk.END)
            self.text_widget.insert(tk.END, last_state)

    def redo(self):
        if self.redo_stack:
            # Obter o estado futuro
            next_state = self.redo_stack.pop()
            # Adicionar o estado atual à pilha de undo
            self.undo_stack.append(self.text_widget.get("1.0", tk.END))
            # Atualizar o texto com o estado futuro
            self.text_widget.delete("1.0", tk.END)
            self.text_widget.insert(tk.END, next_state)

if __name__ == "__main__":
    root = tk.Tk()
    app = EditorApp(root)
    
    # Adicionar botões de undo e redo
    undo_button = tk.Button(root, text="Undo", command=app.undo)
    undo_button.pack(side=tk.LEFT)
    redo_button = tk.Button(root, text="Redo", command=app.redo)
    redo_button.pack(side=tk.LEFT)

    root.mainloop()
