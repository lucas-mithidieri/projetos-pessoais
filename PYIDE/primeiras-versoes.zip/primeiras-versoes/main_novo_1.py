from tkinter import Frame, Text, Menu, Toplevel, Listbox, TclError, Scrollbar, LEFT, RIGHT, END, BOTH, Tk
from tkinter import simpledialog
import re, inspect
import types
from textwrap import dedent

def get_func_info(funcao):
    """
    Obtém informações sobre uma função Python.

    Args:
        funcao (callable): A função para a qual se deseja obter informações.

    Returns:
        dict: Um dicionário contendo informações sobre a função, incluindo nomes e tipos
              dos parâmetros, e a documentação da função.

    """
    informacoes = {}

    # Obtendo assinatura
    assinatura = inspect.signature(funcao)
    parametros = assinatura.parameters

    # Obtendo nomes e tipos dos parâmetros
    informacoes['parametros'] = {nome: parametro.annotation.__name__ if parametro.annotation != inspect.Parameter.empty else '' for nome, parametro in parametros.items()}

    # Obtendo documentação da função
    informacoes['docstring'] = funcao.__doc__ or ''

    return informacoes

def get_methods(obj, spacing=20, show_doc=False):
    """
    Obtém os métodos de um objeto e suas documentações.

    Args:
        obj (object): O objeto do qual os métodos serão obtidos.
        spacing (int): O espaçamento usado para formatar a saída.
        show_doc (bool): Se True, retorna um dicionário {'metodo':'documentacao'},
                        se False, retorna uma lista de nomes de métodos.

    Returns:
        list or dict: Uma lista de nomes de métodos se show_doc for False,
                      ou um dicionário {'metodo':'documentacao'} se show_doc for True.
    """
    result = []
    for method_name in dir(obj):
        try:
            method = getattr(obj, method_name)
            if callable(method):
                if show_doc:
                    doc = str(method.__doc__)[0:90] if method.__doc__ else ''
                    result.append({method_name: doc})
                else:
                    result.append(method_name)
        except Exception as e:
            result.append(f"getattr() failed for {method_name}: {str(e)}")

    return result

def close_window(event): 
    if event.widget.widgetName == 'toplevel':
        event.widget.destroy()
    else:
        # Se não for Toplevel, feche o widget pai
        parent = event.widget.master
        parent.destroy()

def add_to_listbox(content, hide_indices=False):
    inspect_window = Toplevel(root)
    inspect_window.title("Inspect Result")
    inspect_window.focus()

    # Impede o redimensionamento horizontal e vertical
    inspect_window.resizable(width=False, height=False)

    # Hotkeys
    inspect_window.bind('<Escape>', close_window)

    # Set the width and height of the window
    inspect_window.geometry("300x50")

    # Make the "Inspect" window non-minimizable
    inspect_window.transient(root)

    # Add a Listbox to the inspection result window
    listbox = Listbox(inspect_window)
    listbox.pack(side=LEFT, expand=True, fill=BOTH)

    if isinstance(content, (list, tuple, set)):
        # If it's a collection, add a vertical scrollbar to the Listbox
        scrollbar = Scrollbar(inspect_window, command=listbox.yview)
        scrollbar.pack(side=RIGHT, fill=BOTH)

        # Attach Listbox to Scrollbar
        listbox.config(yscrollcommand=scrollbar.set)

        # Setting scrollbar command parameter
        scrollbar.config(command=listbox.yview)

        # Increase window size
        inspect_window.geometry(f"{300}x{230}")

        # Set the index str
        index_str = '""' if hide_indices else "f'[{i}] '"

        # Iterate over the elements and insert them into the Listbox
        for i, item in enumerate(content):
            listbox.insert(END, f'{eval(index_str)}{item}')

    else:
        # If it's not a collection, insert the entire result into the Listbox
        listbox.insert(END, f'[{type(content).__name__}] {content}')

def inspect_code(event=None):
    # Get the selected text from the editor
    selected_code = editor.get("sel.first", "sel.last")
    
    # Executa no escopo global
    exec(selected_code, globals())
    
    # Execute the selected code using eval and display the result.
    try:
        # Execute the code using eval
        result = eval(selected_code)

        # Variável que controla se vai indexar os itens da lista
        hide_indices = False

        # Check if the result is a module, then retrieve its methods
        if isinstance(result, types.ModuleType):
            result = get_methods(result)
        
        if isinstance(result, types.FunctionType):
            function_name = result.__name__
            result = get_func_info(result)
            params = [f'{k}' + (f': {v}' if v else '') for k, v in result['parametros'].items()]
            result = [f'<Name>  {function_name}',
                       f'<Params>  {params}',
                       f'<Docstring>  {dedent(result["docstring"])}']
            
            hide_indices = True

        # Display the result by adding it to the listbox
        add_to_listbox(result, hide_indices)

        # Print the result for debugging or logging purposes
        print(result)

    except:
        result = True

        # verifico se é inspect de declaração 'a = b'
        pattern = r'^\s*([^=\s]+)\s*='

        match = re.search(pattern, selected_code)  

        if match:
            # Avaliando e armazenando o valor da última variável definida
            result = eval(list(globals())[-1])

        add_to_listbox(result)

    # try:
    #     result = eval(selected_code)

    #     if type(result) == types.ModuleType:
    #         result = get_methods(result)

    #     add_to_listbox(result)

    #     print(result)
    # except:
    #     pass

root = Tk()
editor = Text(root, padx=10, pady=10, tabs=(2,))
editor.pack(expand=True, fill='both')

# Create a menu bar
menubar = Menu(root)
root.config(menu=menubar)

# Create a "File" menu
file_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="File", menu=file_menu)

# Add a command to the "File" menu
file_menu.add_command(label="Exit", command=root.destroy)

# Create an "Inspect" menu item outside the "File" menu
menubar.add_command(label="Inspect", command=inspect_code)

# Center the main window on the screen
window_width = 800  # Set your desired width
window_height = 600  # Set your desired height
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2

root.geometry(f"{window_width}x{window_height}+{x}+{y}")

# hotkey binding
root.bind('<Control-I>', inspect_code)
root.mainloop()