from tkinter import *
from tkinter import simpledialog
import re

class MainWindow(Frame):
    def __init__(self, master=None, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.editor = Text(self)
        self.editor.pack(expand=True, fill='both')

        # Create a menu bar
        menubar = Menu(root)
        root.config(menu=menubar)

        # Create a "File" menu
        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)

        # Add a command to the "File" menu
        file_menu.add_command(label="Exit", command=root.destroy)

        # Create an "Inspect" menu item outside the "File" menu
        menubar.add_command(label="Inspect", command=self.inspect_code)

    def inspect_code(self):
        # Get the selected text from the editor
        selected_code = self.editor.get("sel.first", "sel.last")
        
        # Check if there is any code to execute
        if selected_code:

            try:
                # Execute the code
                result = eval(selected_code)
            except:
                try:
                    # Definindo um padrão para extrair a variável da string
                    pattern = r'^\s*([^=\s]+)\s*='
                    
                    # Procurando por uma correspondência no código selecionado
                    case = 0
                    match = re.search(pattern, selected_code)
                    case = 1 if match else 0

                    # import ou from
                    match, case = (re.search(r'\b(import|from)\s+\w+', selected_code),\
                        2) if case==0 else (match, case)

                    # metodo ou function call
                    match, case = (re.search(r'^\w+(?:\.\w+)?\s*\([^)]*\)\s*(?:\.\s*\w+\s*\()?', selected_code),\
                        3) if case==0 else (match, case)

                    if case == 1:
                        # Extraindo a variável da correspondência
                        result = match.group(1)

                        # Executando a atribuição global da variável no código
                        exec(f'global {result}; {selected_code}')

                        # pego a variavel recem criada
                        last_set_var = result

                        # Avaliando e armazenando o valor da última variável definida
                        result = globals()[last_set_var]

                    elif case == 2:
                        if match.group(1) == 'import':
                            pattern = r'import\s+([\w\s,]+)'
                            match = re.search(pattern, selected_code)
                            
                            libraries = [library.strip().split(' as ') for library in match.group(1).split(',')]
                            
                            # Inicializando o dicionário
                            library_dict = {}

                            for lib in libraries:
                                # o proprio nome
                                nome = lib[0]
                                apelido = nome

                                if len(lib) > 1:
                                    # Com apelido
                                    apelido = lib[1]
                                
                                globals()[apelido] = __import__(nome)

                        #globals()[module_name] = __import__(module_name)
                        result = True
                    elif case == 3:
                        # Verifica se é chamada de metodo ou funcao
                        c = f'result = {selected_code}'
                        exec(c)
                        print('é')
                    else:
                        # Lançando uma exceção se não encontrar a variável na string
                        raise ValueError("Problema com a string: não foi possível encontrar a variável")

                except Exception as e:
                    # Handle errors
                    self.add_to_listbox(f"Error: {e}")

            # Add the result to the Listbox
            self.add_to_listbox(result)
        else:
            # Handle case where no code is provided
            self.add_to_listbox("No code selected or entered.")

    def add_to_listbox(self, result):
        # Create a new window for the inspection result
        inspect_result_window = Toplevel(self)
        inspect_result_window.title("Inspect Result")

        # Set the width and height of the window
        inspect_result_window.geometry("200x50")

        # Add a Listbox to the inspection result window
        listbox = Listbox(inspect_result_window)
        listbox.pack(expand=True, fill=BOTH)

        # # Insert the result into the Listbox
        # listbox.insert(END, str(result))
        # Check if result is a list, array, or set
        if isinstance(result, (list, tuple, set)):
            i = 0
            # If it is, iterate over the elements and insert them into the Listbox
            for item in result:
                listbox.insert(END, f'[{str(i)}] {str(item)}')
                i += 1
        else:
            # If it's not, insert the entire result into the Listbox
            listbox.insert(END, f'[{type(result).__name__}] {str(result)}')

        # Center the Listbox within the Toplevel window
        inspect_window = inspect_result_window
        root.update_idletasks()
        x = root.winfo_x() + (root.winfo_width() - inspect_window.winfo_reqwidth()) // 2
        y = root.winfo_y() + (root.winfo_height() - inspect_window.winfo_reqheight()) // 2

        # Set the position of the "Inspect" window to the center
        inspect_window.geometry(f"+{x}+{y}")

        print(result)

if __name__ == "__main__":
    root = Tk()
    main_window = MainWindow(root)
    main_window.pack(side='top', fill='both', expand=True)
    root.mainloop()
