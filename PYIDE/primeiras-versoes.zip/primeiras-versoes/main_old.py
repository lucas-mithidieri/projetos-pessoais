from tkinter import *

class MainWindow(Frame):
    def __init__(self, master=None, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.editor = Text(self)
        self.editor.pack(expand=True, fill='both')

        # Create a menu bar
        menubar = Menu(root)
        root.config(menu=menubar)

        # Create a "File" menu
        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)

        # Add a command to the "File" menu
        file_menu.add_command(label="Exit", command=root.destroy)

        # Create an "Inspect" menu item outside the "File" menu
        menubar.add_command(label="Inspect", command=self.open_inspect_window)

    def inspect(code):
        try:
            res = exec(code)
            
            type()
        except:
            'selection error'
        
    def open_inspect_window(self):
        # Create a new window for inspection
        inspect_window = Toplevel(self)
        inspect_window.title("Inspect Window")

        # Set a fixed width for the "Inspect" window
        inspect_window.geometry("300x200")

        # Disable resizing of the "Inspect" window
        inspect_window.resizable(False, False)

        # Make the "Inspect" window non-minimizable
        inspect_window.transient(root)

        # Calculate the center position of the main window
        root.update_idletasks()
        x = root.winfo_x() + (root.winfo_width() - inspect_window.winfo_reqwidth()) // 2
        y = root.winfo_y() + (root.winfo_height() - inspect_window.winfo_reqheight()) // 2

        # Set the position of the "Inspect" window to the center
        inspect_window.geometry(f"+{x}+{y}")

        # Add a Listbox to the inspection window
        listbox = Listbox(inspect_window)
        listbox.pack(side=LEFT, expand=True, fill=BOTH)

        # Add a vertical scrollbar to the Listbox
        scrollbar = Scrollbar(inspect_window, command=listbox.yview)
        scrollbar.pack(side=RIGHT, fill=BOTH)

        # Insert elements into the listbox
        for values in range(100):
            listbox.insert(END, values)

        # Attaching Listbox to Scrollbar
        listbox.config(yscrollcommand=scrollbar.set)

        # Setting scrollbar command parameter
        scrollbar.config(command=listbox.yview)

if __name__ == "__main__":
    root = Tk()
    main_window = MainWindow(root)
    main_window.pack(side='top', fill='both', expand=True)
    root.mainloop()
