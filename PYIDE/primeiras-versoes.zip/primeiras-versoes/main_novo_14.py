from tkinter import Button, Frame, Text, Menu, Toplevel, Listbox, TclError, Scrollbar, LEFT, TOP, RIGHT, END, BOTH, Tk
from PIL import Image, ImageTk
from tkinter import simpledialog
import re, inspect
import types
from textwrap import dedent
import idlelib.colorizer as ic
import idlelib.percolator as ip
from collections.abc import Iterable
import sys
import os

def DumpObject (obj:object)->dict:
    return vars(obj)

def get_func_info(funcao):
    """
    Obtém informações sobre uma função Python.

    Args:
        funcao (callable): A função para a qual se deseja obter informações.

    Returns:
        dict: Um dicionário contendo informações sobre a função, incluindo nomes e tipos
              dos parâmetros, e a documentação da função.

    """
    informacoes = {}

    # Obtendo assinatura
    assinatura = inspect.signature(funcao)
    parametros = assinatura.parameters

    # Obtendo nomes e tipos dos parâmetros
    informacoes['parametros'] = {nome: parametro.annotation.__name__ if parametro.annotation != inspect.Parameter.empty else '' for nome, parametro in parametros.items()}

    # Obtendo documentação da função
    informacoes['docstring'] = funcao.__doc__ or ''

    return informacoes

# def get_methods(obj, spacing=20, show_doc=False):
#     """
#     Obtém os métodos de um objeto e suas documentações.

#     Args:
#         obj (object): O objeto do qual os métodos serão obtidos.
#         spacing (int): O espaçamento usado para formatar a saída.
#         show_doc (bool): Se True, retorna um dicionário {'metodo':'documentacao'},
#                         se False, retorna uma lista de nomes de métodos.

#     Returns:
#         list or dict: Uma lista de nomes de métodos se show_doc for False,
#                       ou um dicionário {'metodo':'documentacao'} se show_doc for True.
#     """
#     result = []
#     for method_name in dir(obj):
#         try:
#             method = getattr(obj, method_name)
#             if callable(method):
#                 if show_doc:
#                     doc = str(method.__doc__)[0:90] if method.__doc__ else ''
#                     result.append({method_name: doc})
#                 else:
#                     result.append(method_name)
#         except Exception as e:
#             result.append(f"getattr() failed for {method_name}: {str(e)}")

#     return result


def get_methods(obj):
    """
    Obtém os nomes das funções (métodos) definidos em uma classe.

    Parâmetros:
    - obj: Um objeto representando a classe.

    Retorna:
    Uma lista contendo os nomes das funções (métodos) definidos na classe.

    Exemplo:
    ```python
    class MinhaClasse:
        def metodo1(self):
            pass

        def metodo2(self):
            pass

    nomes_metodos = get_methods(MinhaClasse)
    print("Nomes dos métodos:", nomes_metodos)
    ```
    """
    membros_classe = inspect.getmembers(obj)
    funcoes_classe = [membro for membro in membros_classe if inspect.isfunction(membro[1])]
    nomes_funcoes = [funcao[0] for funcao in funcoes_classe]
    return nomes_funcoes

def tab_pressed(event=None):
    selected_code = editor.get("sel.first", "sel.last")

    if selected_code == '':
        # Insert the 4 spaces
        editor.insert("insert", " "*4)
        return "break"
    else:
        # Garante que o texto da 1a linha seja toda a linha
        start_index = editor.index("sel.first").split('.')[0] + ".0"
        selected_code = editor.get(start_index, "sel.last")

    tabs = f'\n{" "*4}'
    new_str = " "*4 + selected_code.replace('\n', tabs)
    
    # previne tabs adicionais no Ctrl+A
    if selected_code[-1] == '\n':
        new_str = new_str[:-5]

    # Obtém a posição inicial e final da seleção
    # start_index = editor.index("sel.first")
    end_index = editor.index("sel.last")

    # Substitui o texto selecionado
    editor.delete(start_index, end_index)
    editor.insert(start_index, new_str)

    # Seleciona o texto recém substituído
    # Obtém a posição do final do texto após a inserção
    end_index = editor.index(tk.INSERT)
    editor.tag_add("sel", start_index, end_index)

    # Prevent the default Tab behaviour call
    return "break"

def delete_instance(obj):
    del obj

class IORedirector(object):
    '''A general class for redirecting I/O to this Text widget.'''
    def __init__(self,text_area):
        self.text_area = text_area
    
    def flush(self):
        pass

class StdoutRedirector(IORedirector):
    '''A class for redirecting stdout to this Text widget.'''
    def write(self,str):
        self.text_area.config(state='normal')
        self.text_area.insert("end", str)
        self.text_area.config(state='disabled')
    
    def flush(self):
        pass

import tkinter as tk

class CreateToolTip:
    def __init__(self, widget, text='widget info'):
        self.waittime = 500
        self.wraplength = 180
        self.widget = widget
        self.text = text
        self.id = None
        self.tw = None

        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)
        self.widget.bind("<ButtonPress>", self.leave)

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hidetip()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(self.waittime, self.showtip)

    def unschedule(self):
        if self.id:
            self.widget.after_cancel(self.id)
            self.id = None

    def showtip(self, event=None):
        x, y, cx, cy = self.widget.bbox("insert")
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20

        self.tw = tk.Toplevel(self.widget)
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))

        label = tk.Label(self.tw, text=self.text, justify='left',
                         background="#ffffff", relief='solid', borderwidth=1,
                         wraplength=self.wraplength)
        label.pack(ipadx=1)

    def hidetip(self):
        if self.tw:
            self.tw.destroy()
            self.tw = None

class InspectWindow:
    def __init__(self, var='', value='', selected_code='') -> types.NoneType:
        self.var = var
        self.value = value
        self.obj_type = type(value)
        self.selection = selected_code
        self.spawn()
    
    def close_window(self, event=None): 
        self.inspect_window.destroy()
        # apaga da memória
        delete_instance(self)

    def spawn(self):
        # entry point
        obj_type = self.obj_type
        value = self.value
        is_iterable = obj_type is str or isinstance(value, Iterable)
        is_callable = callable(value)
        is_class = (obj_type == type)
        is_module = (obj_type is types.ModuleType)
        is_object = 'object at' in repr(value) and 'bound method' not in repr(value)
        
        # refatorar
        title = value if is_callable and value == '' else self.selection
        
        if is_module == False:
            title = self.var
        # fim refatorar
            
        # New window
        self.inspect_window = Toplevel(root)
        inspect_window = self.inspect_window
        inspect_window.title(f"Inspect {': ' + title}")
        inspect_window.focus()

        # Hotkeys
        inspect_window.bind('<Escape>', self.close_window)

        # Impede o redimensionamento horizontal e vertical
        inspect_window.resizable(width=False, height=False)

        # Make the "Inspect" window non-minimizable
        inspect_window.transient(root)

        # Set the width and height of the window
        inspect_window.geometry("300x60")
        
        # Default
        can_resize = True
        builtin_with_no_calls = False

        # Increase window size
        if is_iterable or is_class or is_callable:

            # trecho apenas pra corrigir bug inspect
            # builtins 'int, print, etc'
            if is_callable:
                try:
                    get_func_info(value)
                except:
                    can_resize = False
                    builtin_with_no_calls = True

            if can_resize:
                inspect_window.geometry(f"{300}x{230}")

        # Calcula as coordenadas para centralizar a janela filha em relação à janela principal
        window_width = inspect_window.winfo_reqwidth()
        window_height = inspect_window.winfo_reqheight()
        root_x = root.winfo_rootx()
        root_y = root.winfo_rooty()
        position_x = root_x + int((root.winfo_width() - window_width) / 2) - 50
        position_y = root_y + int((root.winfo_height() - window_height) / 2)
        inspect_window.geometry("+{}+{}".format(position_x, position_y))

        #################################################
        # Adiciona um novo Listbox acima do original
        new_listbox = Listbox(inspect_window, height=1, activestyle="none")
        new_listbox.pack(fill=BOTH)
        if not is_object:
            new_listbox.insert(END, {self.obj_type})        

        # frame pra agrupar a lista e o scroll
        group_frame = Frame(inspect_window)
        group_frame.pack(expand=True, fill=BOTH)

        # Add a Listbox to the inspection result window
        listbox = Listbox(group_frame, height=1, activestyle="none")
        listbox.pack(side=LEFT,expand=True, fill=BOTH)
        ##################################################
        
            
        if builtin_with_no_calls:
            return

        # Add values
        if is_iterable:
            iterator = enumerate(value)
            index_str = "''" if obj_type == set else "f'[{i}] '"

            if obj_type == str:
                listbox.insert(END, f' {value}')
                return

            if obj_type == dict:
                iterator = value.items()

            for i, item in iterator:
                listbox.insert(END, f'{eval(index_str)}{item}')
        
        elif is_callable:
            iterator = get_func_info(value)
            params = iterator['parametros']
            docstr = iterator['docstring']
            s = ''
            for k,v in params.items():
                s += f', {k} : {v}' if v != '' else f', {k}'
            
            listbox.insert(END, f'<Name>  {value.__name__}')
            listbox.insert(END, f'<Params>  ({s[1:]} )')
            listbox.insert(END, f'<Docstring>  {dedent(docstr)}')
                
            # verifica se é uma classe
            if is_class:
                methods = get_methods(value)
                listbox.insert(END, f'<Methods>  {methods}')
        
        elif is_module:
            methods = get_methods(value)
            
            listbox.insert(END, f'<Name>  {value.__name__}')
            listbox.insert(END, f'<Methods>  {methods}')

        elif is_object:
            new_listbox.insert(END, f'{value}')

            for k,v in DumpObject(value).items():
                listbox.insert(END, f'<{k}>  {v}')
        else:
            listbox.insert(END, f' {value}')
            

def update_console_log():
    global current_execution
    chr = '' if current_execution == 0 else '\n'
    st = f"{chr}Execution [{current_execution}]:\n"
    start = '1.0' if current_execution == 0 else console.index("end")
    i,d = divmod(float(start), 1)
    end = f'{int(i)}.{int(d * 10) + (len(st))}'
    console.config(state='normal')
    console.insert("end", st)
    console.config(state='disabled')
    console.tag_add("CONSOLE", start, end)
    console.tag_config("CONSOLE", foreground="#859FFF")
    current_execution += 1

def inspect_code(event=None):
    # Get the selected text from the editor
    selected_code = editor.get("sel.first", "sel.last")
    
    # Atualiza o índice da exec atual
    update_console_log()
    
    try:
        # default value
        var_name = ''

        # Verify if its a var selection
        pattern = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

        if pattern.match(selected_code):
            var_name = selected_code

        # Execute the code using eval
        result = eval(selected_code)

        # Spawn new
        window = InspectWindow(var_name, result, selected_code)

    except:
        try:
            # Executa no escopo global
            exec(selected_code, globals())

            result = True
            var_name = ''

            # verifico se é inspect de declaração 'a = b'
            # pattern = r'^\s*([^=\s]+)\s*='
            pattern = r'(\w+?)(\s?)='

            match = re.search(pattern, selected_code)  

            if match:
                # Avaliando e armazenando o valor da última variável definida
                var_name = match.group(1) #list(globals())[-1]
                result = eval(var_name)

            # Spawn new
            window = InspectWindow(var_name, result, selected_code)

        except:
            # nada deu certo..
            pass

def run_all(event=None):
    # Get the selected text from the editor
    selected_code = editor.get("1.0", "end-1c")  # Obtém o texto selecionado

    update_console_log()

    try:
        eval(selected_code)
    except:
        try:
            # Executa no escopo global
            exec(selected_code, globals())
        except:
            print('Erro')
    
    return 'break'

            
def scroll_end(event):
    console.see(END)
    console.edit_modified(0)

def img_button(toolbar, tooltip, image_path, cmd):
    """
    Cria um botão com imagem em uma barra de ferramentas.

    Parâmetros:
    - toolbar (tkinter.Frame): A barra de ferramentas onde o botão será adicionado.
    - tooltip (str): O texto da dica de ferramenta exibido quando o mouse paira sobre o botão.
    - cmd (callable): A função que será chamada quando o botão for pressionado.
    - image_path (str): O caminho para a imagem que será exibida no botão.

    Retorna:
    - tkinter.Button: O objeto de botão criado.

    Exemplo de uso:
    base_dir = "/caminho/do/diretorio"
    exitButton = img_button(toolbar, '(Ctrl+Shift+P) Run all', your_command_function, f"{base_dir}\\inspect.png")
    """
    img = Image.open(image_path)
    eimg = ImageTk.PhotoImage(img)

    button = Button(toolbar, image=eimg, relief='flat', command=cmd)
    button.pack(padx=2, pady=2)

    # CreateToolTip(widget=button, text=tooltip)

    return button
    
# Entry point
base_dir = os.path.dirname(__file__)

root = Tk()
root.title('PYIDE')
root.configure( background='#131313')
current_execution = 0

# Create Toolbar
toolbar = Frame(root, bd=1, relief='raised')
tools = Frame(toolbar, bd=0, relief='flat')

img = Image.open(f"{base_dir}\\play.png")
eimg = ImageTk.PhotoImage(img)
exitButton = Button(tools, image=eimg, bd=1, relief='raised',
                    command=run_all)
exitButton.pack(side='left', padx=2, pady=2)
CreateToolTip(widget=exitButton, text='(Ctrl+ENTER) Run all')

img2 = Image.open(f"{base_dir}\\inspect.png")
eimg2 = ImageTk.PhotoImage(img2)
exitButton2 = Button(tools, image=eimg2, bd=1, relief='raised', 
                     command=inspect_code)
exitButton2.pack(side='left', padx=2, pady=2)
CreateToolTip(widget=exitButton2, text='(Ctrl+Shift+I) Inspect selected')

toolbar.pack(side=TOP, fill='x')
tools.pack()

######################################################
group_frame = Frame(root)
group_frame.pack(expand=True, fill='y')

editor = Text(group_frame, background='#0D0D0D', foreground="white", insertbackground="white", padx=10, pady=10, tabs=(32,), font=("Consolas", 14), height=4)
editor.pack(side='left', expand=True, fill='y')
editor.bind("<Tab>", tab_pressed)

# Adicionar barra de rolagem vertical
scrollbar = Scrollbar(group_frame, command=editor.yview)
scrollbar.pack(side=RIGHT, fill='y')

# Configurar a barra de rolagem para rolar o widget Text
editor.config(yscrollcommand=scrollbar.set)
######################################################

group_frame_console = Frame(root)
group_frame_console.pack(fill='y')

# Console widget
console = Text(group_frame_console, background='#0D0D0D', foreground="white", insertbackground="white", padx=10, pady=10, tabs=(32,), font=("Consolas", 14), height=5)
console.pack(side='left', fill='none')
console.bind('<<Modified>>', scroll_end)

# Redirecionar as saídas para o console
sys.stdout = StdoutRedirector(console)

# Adicionar barra de rolagem vertical
scrollbar_console = Scrollbar(group_frame_console, command=console.yview)
scrollbar_console.pack(side=RIGHT, fill='y')

# Configurar a barra de rolagem para rolar o widget Text
console.config(yscrollcommand=scrollbar_console.set)

#################################################
# {SYNTAX_COLORING}
#syntax highlighter patterns
KEYWORD   = r"\b(?P<KEYWORD>False|None|True|and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b"
EXCEPTION = r"([^.'\"\\#]\b|^)(?P<EXCEPTION>ArithmeticError|AssertionError|AttributeError|BaseException|BlockingIOError|BrokenPipeError|BufferError|BytesWarning|ChildProcessError|ConnectionAbortedError|ConnectionError|ConnectionRefusedError|ConnectionResetError|DeprecationWarning|EOFError|Ellipsis|EnvironmentError|Exception|FileExistsError|FileNotFoundError|FloatingPointError|FutureWarning|GeneratorExit|IOError|ImportError|ImportWarning|IndentationError|IndexError|InterruptedError|IsADirectoryError|KeyError|KeyboardInterrupt|LookupError|MemoryError|ModuleNotFoundError|NameError|NotADirectoryError|NotImplemented|NotImplementedError|OSError|OverflowError|PendingDeprecationWarning|PermissionError|ProcessLookupError|RecursionError|ReferenceError|ResourceWarning|RuntimeError|RuntimeWarning|StopAsyncIteration|StopIteration|SyntaxError|SyntaxWarning|SystemError|SystemExit|TabError|TimeoutError|TypeError|UnboundLocalError|UnicodeDecodeError|UnicodeEncodeError|UnicodeError|UnicodeTranslateError|UnicodeWarning|UserWarning|ValueError|Warning|WindowsError|ZeroDivisionError)\b"
BUILTIN   = r"([^.'\"\\#]\b|^)(?P<BUILTIN>abs|all|any|ascii|bin|breakpoint|callable|chr|classmethod|compile|complex|copyright|credits|delattr|dir|divmod|enumerate|eval|exec|exit|filter|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|isinstance|issubclass|iter|len|license|locals|map|max|memoryview|min|next|oct|open|ord|pow|print|quit|range|repr|reversed|round|set|setattr|slice|sorted|staticmethod|sum|super|type|vars|zip)\b"
DOCSTRING = r"(?P<DOCSTRING>(?i:r|u|f|fr|rf|b|br|rb)?'''[^'\\]*((\\.|'(?!''))[^'\\]*)*(''')?|(?i:r|u|f|fr|rf|b|br|rb)?\"\"\"[^\"\\]*((\\.|\"(?!\"\"))[^\"\\]*)*(\"\"\")?)"
STRING    = r"(?P<STRING>(?i:r|u|f|fr|rf|b|br|rb)?'[^'\\\n]*(\\.[^'\\\n]*)*'?|(?i:r|u|f|fr|rf|b|br|rb)?\"[^\"\\\n]*(\\.[^\"\\\n]*)*\"?)"
TYPES     = r"\b(?P<TYPES>bool|bytearray|bytes|dict|float|int|list|str|tuple|object)\b"
NUMBER    = r"\b(?P<NUMBER>((0x|0b|0o|#)[\da-fA-F]+)|((\d*\.)?\d+))\b"
CLASSDEF  = r"(?<=\bclass)[ \t]+(?P<CLASSDEF>\w+)[ \t]*[:\(]" #recolor of DEFINITION for class definitions
DECORATOR = r"(^[ \t]*(?P<DECORATOR>@[\w\d\.]+))"
INSTANCE  = r"\b(?P<INSTANCE>cls)\b"
OPERATOR        = r"(?P<OPERATOR>[+\-*\/])" # não tinha no original
COMMENT   = r"(?P<COMMENT>#[^\n]*)"
SYNC      = r"(?P<SYNC>\n)"

PROG   = rf"{KEYWORD}|{BUILTIN}|{EXCEPTION}|{TYPES}|{OPERATOR}|{COMMENT}|{DOCSTRING}|{STRING}|{SYNC}|{INSTANCE}|{DECORATOR}|{NUMBER}|{CLASSDEF}"
IDPROG = r"(?<!class)\s+(\w+)"

cd         = ic.ColorDelegator()
cd.prog    = re.compile(PROG, re.S|re.M)
cd.idprog  = re.compile(IDPROG, re.S)

# These five lines are optional. If omitted, default colours are used.
TAGDEFS   = {
    'COMMENT': {'foreground': '#868586', 'background': None}, #ok
    'TYPES': {'foreground': '#e9950c', 'background': None}, #ok
    'NUMBER': {'foreground': '#df3079', 'background': None}, #ok
    'BUILTIN': {'foreground': '#e9950c', 'background': None},#ok
    'STRING': {'foreground': '#00a67d', 'background': None},#ok
    'DOCSTRING': {'foreground': '#00a67d', 'background': None},#ok
    'EXCEPTION': {'foreground': '#868586', 'background': None},
    'OPERATOR': {'foreground': 'white', 'background': None},
    'DEFINITION': {'foreground': '#ea2424', 'background': None},#ok
    'DECORATOR': {'foreground': '#868586', 'background': None},#ok
    'INSTANCE': {'foreground': '#00a67d', 'background': None}, #self
    'KEYWORD': {'foreground': '#2e95d3', 'background': None}, #def
    'CLASSDEF': {'foreground': '#ea2424', 'background': None},#classname
}

cd.tagdefs = {**cd.tagdefs, **TAGDEFS}
ip.Percolator(editor).insertfilter(cd)
#################################################

# Create a menu bar
menubar = Menu(root)
root.config(menu=menubar)

# Create a "File" menu
file_menu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="File", menu=file_menu)

# Add a command to the "File" menu
file_menu.add_command(label="Exit", command=root.destroy)

# Create an "Inspect" menu item outside the "File" menu
# menubar.add_command(label="Inspect", command=inspect_code)

# Center the main window on the screen
window_width = 1024  # Set your desired width
window_height = 600  # Set your desired height
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

x = (screen_width - window_width) // 2
y = (screen_height - window_height) // 2

root.geometry(f"{window_width}x{window_height}+{x}+{y}")

def remove_tabs(event=None):
    selected_code = editor.get("sel.first", "sel.last")
    
    is_empty_selection = selected_code == ''

    if is_empty_selection:
        # Obtém a posição do cursor no formato "linha.coluna"
        cursor_position = editor.index(tk.INSERT)
        
        # Obtém o início da linha atual (linha.atividade_inicial)
        start_index = cursor_position.split('.')[0] + ".0"

        # Obtém o final da linha atual (linha.atividade_final)
        end_index = cursor_position.split('.')[0] + ".end"

        # Obtém o texto da linha atual
        selected_code = editor.get(start_index, end_index)

        # Garante que não está vazio o editor
        if selected_code == '':
            return 'break'
    else:
        # Garante que o texto da 1a linha seja toda a linha
        start_index = editor.index("sel.first").split('.')[0] + ".0"
        selected_code = editor.get(start_index, "sel.last")

    # Verifica se o primeiro caractere de selected_code 
    # não é uma quebra de linha.
    missing_new_line_char = selected_code[0] != '\n'

    # Adiciona uma quebra de linha no início de selected_code
    # se estiver faltando.
    if  missing_new_line_char:
        selected_code = '\n' + selected_code

    # Substitui todas as ocorrências de tabs 
    # por uma quebra de linha em selected_code.
    tabs = f'\n{" "*4}'
    new_str = selected_code.replace(tabs, '\n')
    
    # Remove a quebra de linha no final se houver
    if selected_code[-1] == '\n':
        new_str = new_str[:-1]    

    # Remove a primeira quebra de linha 
    # se ela tiver sido adicionada anteriormente.
    if missing_new_line_char:
        new_str = new_str[1:]

    # Obtém a posição inicial e final da seleção
    if not is_empty_selection:
        # start_index = editor.index("sel.first")
        end_index = editor.index("sel.last")

    # Substitui o texto selecionado
    editor.delete(start_index, end_index)
    editor.insert(start_index, new_str)

    # Seleciona o texto recém substituído
    # Obtém a posição do final do texto após a inserção
    editor.tag_add("sel", start_index, end_index.split('.')[0] + ".end")

    return 'break'
    
# hotkey binding
root.bind('<Control-I>', inspect_code)
editor.bind('<Control-Return>', run_all)
editor.bind('<Shift-Tab>', remove_tabs)
root.mainloop()