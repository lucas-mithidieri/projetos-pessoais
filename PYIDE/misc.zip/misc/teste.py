def sumar(a:int, b:int)->int:
    return a + b