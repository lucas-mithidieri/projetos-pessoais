import tkinter as tk

def execute_code():
    code_to_execute = entry.get()

    try:
        # Inserir um ponto de interrupção
        breakpoint()
        exec(code_to_execute)
    except Exception as e:
        print(f"Erro durante a execução: {e}")

root = tk.Tk()
root.title("Execução Dinâmica com Breakpoint")

entry = tk.Entry(root, width=50)
entry.pack(pady=10)

execute_button = tk.Button(root, text="Executar Código", command=execute_code)
execute_button.pack()

root.mainloop()
