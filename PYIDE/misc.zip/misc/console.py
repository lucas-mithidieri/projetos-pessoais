# import tkinter as tk
# import sys
# import code
# from threading import Thread
# import queue


# class Console(tk.Frame):
#     def __init__(self, parent, _locals, exit_callback):
#         tk.Frame.__init__(self, parent)
#         self.parent = parent
#         self.exit_callback = exit_callback
#         self.destroyed = False

#         self.real_std_in_out = (sys.stdin, sys.stdout, sys.stderr)

#         sys.stdout = self
#         sys.stderr = self
#         sys.stdin = self

#         self.stdin_buffer = queue.Queue()

#         self.createWidgets()

#         self.consoleThread = Thread(target=lambda: self.run_interactive_console(_locals))
#         self.consoleThread.start()

#     def run_interactive_console(self, _locals):
#         try:
#             code.interact(local=_locals)
#         except SystemExit:
#             if not self.destroyed:
#                 self.after(0, self.exit_callback)

#     def destroy(self):
#         self.stdin_buffer.put("\n\nexit()\n")
#         self.destroyed = True
#         sys.stdin, sys.stdout, sys.stderr = self.real_std_in_out
#         super().destroy()

#     def enter(self, event):
#         input_line = self.ttyText.get("input_start", "end")
#         self.ttyText.mark_set("input_start", "end-1c")
#         self.ttyText.mark_gravity("input_start", "left")
#         self.stdin_buffer.put(input_line)

#     def write(self, string):
#         self.ttyText.insert('end', string)
#         self.ttyText.mark_set("input_start", "end-1c")
#         self.ttyText.see('end')

#     def createWidgets(self):
#         self.ttyText = tk.Text(self.parent, wrap='word')
#         self.ttyText.grid(row=0, column=0, sticky=tk.N + tk.S + tk.E + tk.W)
#         self.ttyText.bind("<Return>", self.enter)
#         self.ttyText.mark_set("input_start", "end-1c")
#         self.ttyText.mark_gravity("input_start", "left")

#     def flush(self):
#         pass

#     def readline(self):
#         line = self.stdin_buffer.get()
#         return line


# if __name__ == '__main__':
#     root = tk.Tk()
#     root.config(background="red")
#     main_window = Console(root, locals(), root.destroy)
#     main_window.mainloop()

import tkinter as tk
import sys
import code
from threading import Thread
import queue

class Console(tk.Frame):
    def __init__(self, parent, _locals, exit_callback):
        tk.Frame.__init__(self, parent)
        self.parent = parent
        self.exit_callback = exit_callback
        self.destroyed = False

        # Salva as referências para os objetos originais de stdin, stdout e stderr
        self.real_std_in_out = (sys.stdin, sys.stdout, sys.stderr)

        # Redireciona stdin, stdout e stderr para a instância da classe Console
        sys.stdout = self
        sys.stderr = self
        sys.stdin = self

        # Fila para armazenar as entradas do usuário
        self.stdin_buffer = queue.Queue()

        # Inicializa a interface gráfica
        self.createWidgets()

        # Inicia uma thread para executar o console interativo
        self.consoleThread = Thread(target=lambda: self.run_interactive_console(_locals))
        self.consoleThread.start()

    def run_interactive_console(self, _locals):
        try:
            # Inicia o console interativo usando a função interact do módulo code
            code.interact(local=_locals)
        except SystemExit:
            # Trata a exceção SystemExit, chamando o callback de saída se necessário
            if not self.destroyed:
                self.after(0, self.exit_callback)

    def destroy(self):
        # Adiciona um comando de saída na fila para encerrar o console interativo
        self.stdin_buffer.put("\n\nexit()\n")
        self.destroyed = True

        # Restaura os objetos originais de stdin, stdout e stderr
        sys.stdin, sys.stdout, sys.stderr = self.real_std_in_out
        super().destroy()

    def enter(self, event):
        # Obtém a linha de entrada do usuário e a coloca na fila de entradas
        input_line = self.ttyText.get("input_start", "end")
        self.ttyText.mark_set("input_start", "end-1c")
        self.ttyText.mark_gravity("input_start", "left")
        self.stdin_buffer.put(input_line)

    def write(self, string):
        # Escreve a saída do console na interface gráfica
        self.ttyText.insert('end', string)
        self.ttyText.mark_set("input_start", "end-1c")
        self.ttyText.see('end')

    def createWidgets(self):
        # Cria o widget de texto para exibir a saída e receber a entrada do usuário
        self.ttyText = tk.Text(self.parent, wrap='word')
        self.ttyText.grid(row=0, column=0, sticky=tk.N + tk.S + tk.E + tk.W)
        self.ttyText.bind("<Return>", self.enter)
        self.ttyText.mark_set("input_start", "end-1c")
        self.ttyText.mark_gravity("input_start", "left")

    def flush(self):
        # Método obrigatório, mas não utilizado neste contexto
        pass

    def readline(self):
        # Lê uma linha da fila de entradas do usuário
        line = self.stdin_buffer.get()
        return line

# Verifica se o script está sendo executado como um programa independente
if __name__ == '__main__':
    # Cria uma janela principal usando tkinter
    root = tk.Tk()
    root.config(background="red")

    # Inicializa a instância da classe Console
    main_window = Console(root, locals(), root.destroy)
    
    # Inicia o loop principal da interface gráfica
    main_window.mainloop()
